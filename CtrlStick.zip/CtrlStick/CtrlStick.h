/*Libreria molto semplice per l'utilizzo del pulsante joystick
  Probabilmente migliorabile, l'ho usata anche per fare pratica
*/
#ifndef CtrlStick_h
#define CtrlStick_h
#include "Arduino.h"
#define delay_ 500                    //delay tra ogni controllo se il joystick si è spostato
class CtrlStick{
	public:
		CtrlStick(int x,int y);
		char pos();
	private:
		int _joyX,_joyY;
};
	
#endif
