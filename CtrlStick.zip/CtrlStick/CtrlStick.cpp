#include "CtrlStick.h"
#include "Arduino.h"

CtrlStick::CtrlStick(int x,int y){
  _joyX=x;
  _joyY=y;
}
char CtrlStick::pos(){
	int xValue,yValue;
	xValue = analogRead(_joyX);
	yValue = analogRead(_joyY);
    if(xValue > 1000){
        delay(delay_);
        return 'r';                                             //right
    }
    if(xValue < 100){
        delay(delay_);
        return 'l';                                             //left
    }
    if(yValue < 100){
        delay(delay_);
        return 'u';												//up
    }
	if(yValue > 1000){
        delay(delay_);
        return 'd';												//down
    }
	return '0';
}
